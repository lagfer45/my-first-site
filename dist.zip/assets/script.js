
document.addEventListener("DOMContentLoaded", () => {
  console.log("Сайт загружен и работает!");
});
